class Supplier < ApplicationRecord
  has_many :products

end
